import { entries } from './data'
import { CardList } from './components/Cards.jsx'
import { useState } from 'react'

export function Blog(){
    const [filteredText, setFilteredText] = useState("") 

    function handleChange(e){
        setFilteredText(e.target.value)
    }

    return(
        <>
        <h1>Animales</h1>
        <div className='filter'>
            <table>
            <tr>
                <td>Buscar</td>
                <td><input type='text' value={filteredText} onChange={handleChange}></input></td>
            </tr>
            </table>
        </div>
        <div className='cardlist'>
            <CardList entries={entries} filteredText={filteredText}></CardList>
        </div>
        </>
    )
}